﻿using MarketMapIT488.ViewModels;
using System.ComponentModel;
using Xamarin.Forms;

namespace MarketMapIT488.Views
{
    public partial class ItemDetailPage : ContentPage
    {
        public ItemDetailPage()
        {
            InitializeComponent();
            BindingContext = new ItemDetailViewModel();
        }
    }
}