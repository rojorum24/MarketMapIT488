﻿using Xamarin.Forms;

namespace MarketMapTeam6
{
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();
           
        }

    }
}
